const crypto=require("crypto");
const secret=()=>process.env.SESSION_SECRET||"CHANGE_ME";
function makeSession(email){const v=Buffer.from(JSON.stringify({email,exp:Date.now()+28800000})).toString("base64url");return v+"."+crypto.createHmac("sha256",secret()).update(v).digest("hex")}
function readSession(req){const m=(req.headers.cookie||"").match(/(?:^|;\s*)chapel_admin=([^;]+)/);if(!m)return null;try{const [v,s]=decodeURIComponent(m[1]).split(".");const good=crypto.createHmac("sha256",secret()).update(v).digest("hex");if(!s||s!==good)return null;const d=JSON.parse(Buffer.from(v,"base64url").toString());return d.exp>Date.now()?d:null}catch{return null}}
function requireAdmin(req,res){const s=readSession(req);if(!s){res.status(401).json({error:"Admin login required."});return null}return s}
module.exports={makeSession,readSession,requireAdmin};