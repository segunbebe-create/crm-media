# CRM Media – Vercel Blob setup

## What was updated
- Added `@vercel/blob` to `package.json`.
- Added `api/upload.js` for admin-only media uploads.
- Uploaded files are stored in the connected Vercel Blob store under `media/`.
- Blob objects are public so members can view/download them.

## IMPORTANT: Vercel environment variable
In the CRM Media project on Vercel, add:

`ADMIN_EMAIL, ADMIN_PASSWORD and SESSION_SECRET`

Use a private value that only the admin knows.

The Blob connection should already provide:

`BLOB_STORE_ID`
`BLOB_WEBHOOK_PUBLIC_KEY`
`BLOB_READ_WRITE_TOKEN`

Do not publish or share the values of these variables.

## Deploy
Redeploy the project after adding `ADMIN_EMAIL, ADMIN_PASSWORD and SESSION_SECRET`.

## Front-end upload request
The admin upload page should send:
- POST `/api/upload`
- Header `Authorization: Bearer YOUR_ADMIN_EMAIL, ADMIN_PASSWORD and SESSION_SECRET`
- Header `X-Filename: original-file-name.jpg`
- Header `Content-Type: image/jpeg`
- Body: the raw file bytes

Do NOT put the admin token directly into public/member-facing code. The safest production setup is to keep upload authorization on the server.
