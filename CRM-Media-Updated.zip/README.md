# CRM Media Vercel version

Public gallery + member favourites/downloads + admin-only login/upload/delete.

Before deployment:
1. Create a Vercel Blob store in the Vercel dashboard under Storage and connect it to this project.
2. Add Environment Variables: ADMIN_EMAIL, ADMIN_PASSWORD, SESSION_SECRET.
3. Redeploy.

Favourites are saved in each member's browser. Images are stored in Vercel Blob.
